package com.example.dinetodoorapp

import android.widget.RatingBar

class Hero(val id: String?, val name: String, val ratingBar: Int)