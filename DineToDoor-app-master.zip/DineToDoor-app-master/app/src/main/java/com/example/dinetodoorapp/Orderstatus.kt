package com.example.dinetodoorapp

data class Orderstatus (

    val orderID : String?= null,
    val statusOrder: String?=null
        )
