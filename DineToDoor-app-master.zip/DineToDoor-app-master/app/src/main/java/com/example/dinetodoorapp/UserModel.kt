package com.example.dinetodoorapp

data class UserModel(
    var id: String? = null,
    val name: String? = null,
    val email: String? = null,
    val uname: String? = null,
    val contactNo: String? = null,
    val address: String? = null)