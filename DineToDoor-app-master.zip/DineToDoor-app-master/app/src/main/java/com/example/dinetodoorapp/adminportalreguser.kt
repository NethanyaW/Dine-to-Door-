package com.example.dinetodoorapp

data class reguser(val username : String ? = null , val email : String ? = null , val Password : String ?= null , val comfpassword : String?=null)