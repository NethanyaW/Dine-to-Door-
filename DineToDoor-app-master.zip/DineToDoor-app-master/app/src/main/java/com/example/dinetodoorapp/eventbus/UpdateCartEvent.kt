package com.example.dinetodoorapp.eventbus

class UpdateCartEvent {
}