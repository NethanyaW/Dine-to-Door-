package com.example.dinetodoorapp.managers

import com.example.dinetodoorapp.model.ProductModel

object CartManager {
    val cartList = ArrayList<ProductModel>()
}