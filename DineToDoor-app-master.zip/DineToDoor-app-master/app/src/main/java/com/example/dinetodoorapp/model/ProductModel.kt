package com.example.dinetodoorapp.model

class ProductModel {
    var image: String? = null
    var name: String? = null
    var price: String? = null
}