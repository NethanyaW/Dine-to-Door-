package com.example.cart

class DrinkModel(icBaselineAddBox24: Int, s: String) {
    var key:String?=null
    var name:String?=null
    var image:String?=null
    var price:String?=null

}