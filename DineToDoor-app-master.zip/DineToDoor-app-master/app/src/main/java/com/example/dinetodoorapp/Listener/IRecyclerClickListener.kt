package com.example.cart.Listener

import android.view.View


interface IRecyclerClickListener {
    fun onItemClickListener(view: View?, position:Int)
}