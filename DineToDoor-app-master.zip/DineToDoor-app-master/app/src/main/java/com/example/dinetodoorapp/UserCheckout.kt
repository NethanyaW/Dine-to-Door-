package com.example.dinetodoorapp

data class UserCheckout(val fullname:String?=null,val phone:String?=null,val email:String?=null,val address:String?=null,val additionalnotes: String?=null,val cash:String?=null,val card:String?=null,val home:String?=null,val office:String?=null){

}
