package com.example.dinetodoorapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class whilist : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_whilist)

        //val shoppagebtn: Button = findViewById(R.id.shoppagebtn)
        //val orderstatuspage: Button = findViewById(R.id.orderstatuspage)



    }
}