package com.example.dinetodoorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class order : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)
    }
}