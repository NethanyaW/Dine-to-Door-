package com.example.dinetodoorapp.model

import java.time.OffsetDateTime

class CartModel {
    var key:String?= null
    var name:String?= null
    var image:String?= null
    var price:String?= null
    var quantity = 0
    var totalPrice = 0f
}