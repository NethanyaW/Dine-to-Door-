package com.example.adminportal

data class Orderstatus (

    val orderID : String?= null,
    val statusOrder: String?=null
        )
